# Importing the required libraries
import tkinter as tk  # For creating the GUI window
from tkinter import messagebox, simpledialog  # For message dialogs
from tkinter import ttk  # For using themed widgets
from datetime import datetime  # For handling date objects
from PIL import Image, ImageTk  # Importing image handling libraries

# Define the main class for the Home Maintenance Scheduler application
class HomeMaintenanceScheduler:
    def __init__(self, master):
        self.master = master  # Main window
        master.title("Home Maintenance Scheduler")
        master.configure(bg='blue')  # Set the background color of the main window to blue

        # Hold the list of tasks that the user adds
        self.tasks = []

        # Create and pack the GUI components
        self.title_label = tk.Label(master, text="Home Maintenance Scheduler", font=("Helvetica", 28), bg='blue', fg='white')
        self.title_label.pack(pady=30)  # Adding vertical padding

        # Load and display the logo image using relative path
        self.logo_image = Image.open("Logo.png")  # Relative path
        self.logo_image = self.logo_image.resize((200, 200), Image.LANCZOS)  # Size the image 
        self.logo = ImageTk.PhotoImage(self.logo_image)
        self.logo_label = tk.Label(master, image=self.logo, bg='blue')  # Set the background of the logo label
        self.logo_label.pack(pady=5)

        # Navigation buttons for different functionalities
        self.schedule_task_button = tk.Button(master, text="Schedule New Task", command=self.open_schedule_task_window, width=15, height=1, font=("Helvetica", 18), bg='lightblue', fg='black')
        self.schedule_task_button.pack(pady=15)

        self.view_tasks_button = tk.Button(master, text="View Scheduled Tasks", command=self.open_view_tasks_window, width=17, height=1, font=("Helvetica", 18), bg='lightblue', fg='black')
        self.view_tasks_button.pack(pady=15)

        self.help_button = tk.Button(master, text="Help", command=self.open_help_window, width=15, height=1, font=("Helvetica", 18), bg='lightblue', fg='black')
        self.help_button.pack(pady=15)

        self.exit_button = tk.Button(master, text="Exit", command=self.exit_application, width=15, height=1, font=("Helvetica", 18), bg='lightblue', fg='black')
        self.exit_button.pack(pady=15)
        
        # Welcome message displayed in the main window
        self.welcome_message = tk.Label(master, text="Manage your home maintenance tasks efficiently!", font=("Helvetica", 16), bg='blue', fg='white')
        self.welcome_message.pack(pady=30)
        
    # Function to exit the application
    def exit_application(self):
        if messagebox.askokcancel("Quit", "Do you want to quit?"):
            self.master.destroy() # Close the main window
            
            
    # Function to open the scheduling window
    def open_schedule_task_window(self):
        self.schedule_window = tk.Toplevel(self.master)  # Create a new window on top
        self.schedule_window.title("Schedule a New Maintenance Task")
        self.schedule_window.configure(bg='blue')  # Set background for the scheduling window
        self.schedule_window.iconbitmap("Icon.ico")  # Relative path

        # Input for task description
        tk.Label(self.schedule_window, text="Task Description:", font=("Helvetica", 16), bg='blue', fg='white').pack(pady=15)
        self.task_description_entry = tk.Entry(self.schedule_window, font=("Helvetica", 16), width=60)
        self.task_description_entry.pack(pady=15)

        # Input for due date
        tk.Label(self.schedule_window, text="Due Date (MM-DD-YYYY):", font=("Helvetica", 16), bg='blue', fg='white').pack(pady=15)
        self.due_date_entry = tk.Entry(self.schedule_window, font=("Helvetica", 16), width=60)
        self.due_date_entry.pack(pady=15)

        # Input for task frequency
        tk.Label(self.schedule_window, text="Frequency:", font=("Helvetica", 16), bg='blue', fg='white').pack(pady=15)
        self.frequency_var = tk.StringVar(value="Monthly")  # Default value
        frequency_options = ["Daily", "Weekly", "Monthly", "Quarterly", "Yearly"]
        self.frequency_menu = ttk.Combobox(self.schedule_window, textvariable=self.frequency_var, values=frequency_options, font=("Helvetica", 16), width=60)
        self.frequency_menu.pack(pady=15)

        # Button to save the task
        self.save_task_button = tk.Button(self.schedule_window, text="Save Task", command=self.save_task, width=15, height=1, font=("Helvetica", 18), bg='lightblue', fg='black')
        self.save_task_button.pack(pady=15)

        # Button to cancel the task scheduling
        self.cancel_button = tk.Button(self.schedule_window, text="Cancel", command=self.schedule_window.destroy, width=15, height=1, font=("Helvetica", 18), bg='lightblue', fg='black')
        self.cancel_button.pack(pady=15)

    # Function to save the task from the entry fields
    def save_task(self):
        description = self.task_description_entry.get()  # Get the task description
        due_date_str = self.due_date_entry.get()  
        frequency = self.frequency_var.get()  

        # Check if both description and due date are filled in
        if description and due_date_str:
            try:
                # Convert the due date string to a date object
                due_date = datetime.strptime(due_date_str, '%m-%d-%Y')
                # Append the task data to the tasks list
                self.tasks.append({"description": description, "due_date": due_date, "frequency": frequency})
                messagebox.showinfo("Success", "Task saved successfully.")  
                self.schedule_window.destroy()  # Close the task scheduling window
            except ValueError:
                messagebox.showerror("Error", "Invalid date format. Please use MM-DD-YYYY.")
        else:
            messagebox.showerror("Error", "Please fill in all fields.")
            
    # Function to view scheduled tasks
    def open_view_tasks_window(self):
        # Create a new window to display scheduled tasks
        self.view_window = tk.Toplevel(self.master)
        self.view_window.title("Scheduled Maintenance Tasks")
        self.view_window.configure(bg='blue') # Set background for the view tasks window
        self.view_window.iconbitmap("Icon.ico")  # Relative path

        # Load and display the logo image using relative path
        self.image = Image.open("Logo.png")  # Relative path
        self.image = self.image.resize((200, 200), Image.LANCZOS)  # Size the image
        self.photo_image = ImageTk.PhotoImage(self.image)
        self.image_label = tk.Label(self.view_window, image=self.photo_image, bg='blue')  # Set the background of the image label
        self.image_label.grid(row=8, column=1, padx=10, pady=10)

        # Listbox to display tasks
        self.tasks_listbox = tk.Listbox(self.view_window, width=80, height=8, font=("Helvetica", 16))
        self.tasks_listbox.grid(row=0, column=1, padx=10, pady=30)

        # Insert tasks into the listbox
        for index, task in enumerate(self.tasks):
            self.tasks_listbox.insert(index, f"{task['description']} - Due: {task['due_date'].strftime('%m-%d-%Y')} - Frequency: {task['frequency']}")

        # Button to delete a selected task
        self.delete_button = tk.Button(self.view_window, text="Delete Task", command=self.delete_task, width=16, height=1, font=("Helvetica", 18), bg='lightblue', fg='black')
        self.delete_button.grid(row=1, column=1, pady=15)

        # Button to mark a selected task as complete
        self.complete_button = tk.Button(self.view_window, text="Mark as Complete", command=self.mark_task_complete, width=16, height=1, font=("Helvetica", 18), bg='lightblue', fg='black')
        self.complete_button.grid(row=2, column=1, pady=15)  

        # Button to return to the main menu
        self.back_button = tk.Button(self.view_window, text="Back to Main Menu", command=self.view_window.destroy, width=16, height=1, font=("Helvetica", 18), bg='lightblue', fg='black')
        self.back_button.grid(row=3, column=1, pady=15)

    # Function to delete a selected task from the list
    def delete_task(self):
        selected_task_index = self.tasks_listbox.curselection()  
        if selected_task_index:  # Check if a task is selected
            del self.tasks[selected_task_index[0]]  
            self.tasks_listbox.delete(selected_task_index)  # Remove from the listbox 
            messagebox.showinfo("Success", "Task deleted successfully.")  
        else:
            messagebox.showwarning("Warning", "Please select a task to delete.")

    # Function to mark a task as complete
    def mark_task_complete(self):
        selected_task_index = self.tasks_listbox.curselection()  
        if selected_task_index:
            task_description = self.tasks[selected_task_index[0]]["description"]  
            messagebox.showinfo("Task Completed", f"Task '{task_description}' marked as complete.")  
            del self.tasks[selected_task_index[0]]  
            self.tasks_listbox.delete(selected_task_index)
        else:
            messagebox.showwarning("Warning", "Please select a task to mark as complete.")

    # Function to open the help window
    def open_help_window(self):
        self.help_window = tk.Toplevel(self.master)
        self.help_window.title("Help and Support")
        self.help_window.configure(bg='blue')  # Set background for the help window
        self.help_window.iconbitmap("Icon.ico")  # Relative path
        
        # Help text explaining the app features and instructions
        help_text = ("Welcome to OB Home Maintenance Scheduler!\n\n"
                     "Features:\n"
                     "- Schedule new maintenance tasks.\n"
                     "- View and manage scheduled tasks.\n"
                     "- Mark tasks as complete or delete them.\n\n"
                     "Instructions:\n"
                     "1. Click 'Schedule New Task' to add a maintenance task.\n"
                     "2. Enter the task details and click 'Save Task'.\n"
                     "3. Click 'View Scheduled Tasks' to see your tasks.\n"
                     "4. You can delete or mark tasks as complete from the list.\n\n"
                     "For support, please contact [obhomemaintence@gmail.com].")

        # Create a label to display the help text
        help_label = tk.Label(self.help_window, text=help_text, justify=tk.LEFT, padx=10, pady=15, bg='blue', fg='white', font=("Helvetica", 16))
        help_label.pack()  

        # Button to go back to the main menu
        self.back_button_help = tk.Button(self.help_window, text="Go Back to Main Menu", command=self.help_window.destroy, width=18, height=1, font=("Helvetica", 18), bg='lightblue', fg='black')
        self.back_button_help.pack(pady=15)

# Main application startup
if __name__ == "__main__":
    root = tk.Tk()
    root.geometry("800x800")  # Set the window size 
    root.iconbitmap("Icon.ico")  # Relative path
    app = HomeMaintenanceScheduler(root)  # Initialize the main application
    root.mainloop()
